---
name: meal-planning
description: Voice-driven family meal planning that integrates Home Assistant custody schedules and activity calendars with Mealie meal planning and shopping lists. Use when the user initiates meal planning conversationally (e.g., "let's plan meals", "gotta meal plan", "help me figure out dinners"). Orchestrates calendar queries, leftover management, inventory updates, meal plan generation matched to schedule complexity, and per-store shopping list creation to reduce cognitive load and food waste for a busy blended family with 2-5-5-2 custody schedules.
---

# Family Meal Planning & Shopping Orchestration

Voice-driven workflow for meal planning with calendar awareness, leftover intelligence, and shopping list management.

## Prerequisites

- **Extended Mealie MCP server** with Home Assistant calendar integration (see Extensions Needed below)
- MCP server connected via Claude.ai Settings → Integrations with:
  - Mealie API credentials
  - Home Assistant URL and long-lived access token
- Home Assistant calendars: `calendar.boys_custody_schedule`, `calendar.girls_custody_schedule`, `calendar.benci_boys`, `calendar.boycivengas`
- Home Assistant todo lists: `todo.mealie_walmart`, `todo.mealie_trader_joes`, `todo.mealie_giant`, `todo.mealie_wegmans`, `todo.mealie_weis`

## Core Workflow

Execute phases sequentially when user initiates meal planning:

### Phase 1: Context Discovery

**Get planning window:**

1. Query current datetime from Home Assistant
2. Fetch custody schedule events for the upcoming week
3. Fetch family activity calendars for the upcoming week
4. Assess schedule complexity (count events, identify late nights)
5. Provide context-aware response and clarify planning window

**Implementation:**

```javascript
// Get current time
Home Assistant:GetDateTime()

// Get custody schedules (extended Mealie MCP server provides these tools)
Mealie:get_custody_schedule({ 
  calendar: "boys_custody_schedule",
  days_ahead: 7 
})

Mealie:get_custody_schedule({ 
  calendar: "girls_custody_schedule",
  days_ahead: 7 
})

// Get activity calendars
Mealie:get_family_events({ 
  calendar: "benci_boys",
  days_ahead: 7 
})

Mealie:get_family_events({ 
  calendar: "boycivengas",
  days_ahead: 7 
})
```

**Response pattern:**

```
"I hear ya - looks like a busy week! The [boys/girls] are with you [days], 
and I see [specific activities]. How much shopping are you ready to do now?"
```

**Clarifications:**
- If no date range provided, ask user to specify duration or specific dates
- Use calendar context to suggest logical planning windows (custody transitions)
- Note time-of-day awareness (Sunday afternoon vs Wednesday night planning)

### Phase 2: Leftover Assessment

**Check for leftovers:**

1. Query recent Mealie meal plans (past 3-7 days)
2. Ask user about current leftover situation
3. Identify rehydration opportunities across custody cycles

**Implementation:**

```javascript
// Use Mealie MCP server
Mealie:get_all_mealplans({ 
  start_date: "2024-01-29",  // 7 days ago
  end_date: "2024-02-05"      // today
})
```

**Leftover tracking strategy:**
- When planning meal with leftovers, add note to Mealie meal plan entry: "Leftover from [date] - no ingredients needed"
- Do NOT add ingredients to shopping list for leftover meals
- Track rehydration across custody cycles in memory: "Made spaghetti with girls Monday → reheat for boys Thursday"

**Example dialogue:**

```
"Before we dive in - any leftovers right now? I see you made chicken 
stir-fry with the girls last Thursday."
```

### Phase 3: Inventory Update

**Accept voice inventory:**

1. Prompt user to list current pantry/fridge contents
2. Query Mealie foods on-hand for baseline
3. Update Mealie inventory as items are mentioned (see Extensions Needed)
4. Acknowledge items incrementally

**Implementation:**

```javascript
// Check current on-hand foods
Mealie:get_foods_on_hand({ search: null })

// TODO: Update foods requires extended MCP server endpoint
// Mealie:update_food_quantity({ food_id: "uuid", quantity: 2, unit: "package" })
```

**For MVP:** Track inventory updates in conversation context, acknowledge verbally. Full inventory sync requires MCP extension.

**Inventory prioritization:**
- Flag items user mentions are "almost empty" or "expiring soon"
- Prioritize recipes using multiple on-hand items
- Suggest bulk purchases for custody-cycle-friendly items

### Phase 4: Meal Plan Generation

**Match meals to schedule:**

1. Cross-reference planning window with calendar events
2. Categorize each evening by complexity needs:
   - **Calm** (no activities): 45-60min recipes, elaborate meals
   - **Moderate** (single activity): 30-45min recipes, one-pot meals
   - **Busy** (late return, multiple activities): <30min recipes, slow cooker
   - **Chaotic** (overlapping activities, very late): Takeout/on-the-go
3. Search Mealie recipes matching complexity and on-hand ingredients
4. Apply 85/15 rule: 85% existing catalog, 15% new recipe exploration
5. Incorporate leftover rehydration from Phase 2
6. Build plan collaboratively, accepting voice modifications
7. Create Mealie meal plan entries in bulk

**Meal complexity matching:**

```javascript
// Search by criteria
Mealie:get_recipes({ 
  search: "quick weeknight",  // or null for browsing
  tags: ["30-minute", "one-pot"],  // as appropriate
  per_page: 5 
})

// Get concise summaries for suggestions
Mealie:get_recipe_concise({ slug: "recipe-slug" })

// Get full recipe when user wants details
Mealie:get_recipe_detailed({ slug: "recipe-slug" })
```

**Takeout management:**
- Suggest takeout strategically for chaotic nights (prevent burnout)
- Track frequency in conversation
- Alert if >3 takeout nights in planning window
- Frame as strategic vs reactive: "This prevents the 'forgot to shop' scramble"

**Create meal plan:**

```javascript
// Bulk create all entries at once
Mealie:create_mealplan_bulk({
  entries: [
    { 
      date: "2024-02-06", 
      recipe_id: "uuid-1", 
      entry_type: "dinner",
      // Note: Add notes field for leftover tracking when creating leftover meals
    },
    { 
      date: "2024-02-07", 
      title: "Takeout - Pizza night",  // Use title when no recipe
      entry_type: "dinner" 
    },
    // ... more entries
  ]
})
```

### Phase 5: Shopping List Generation

**Build store-specific lists:**

1. Extract ingredients from all planned meals
2. De-duplicate against on-hand inventory from Phase 3
3. Assign items to stores using distribution: Walmart (73%), Trader Joe's (20%), Others (7%)
4. Query existing shopping lists
5. Add new items to appropriate store lists
6. Present summary by store

**Store assignment rules (baseline):**
- **Walmart (primary)**: Proteins, dairy, produce (standard), grains, canned goods, frozen basics, bulk items
- **Trader Joe's (specialty)**: Unique sauces, specialty cheeses, frozen prepared, snacks, organic specialty
- **Giant/Wegmans/Weis/Aldi (occasional)**: Store-specific sales, brand preferences, supplemental

**Future enhancement:** Learn from receipt uploads and location-based shopping list completion (see references/shopping-intelligence.md)

**Implementation:**

```javascript
// Query existing lists (via Home Assistant MCP)
Home Assistant:todo_get_items({ 
  todo_list: "Mealie Walmart",
  status: "needs_action" 
})

Home Assistant:todo_get_items({ 
  todo_list: "Mealie Trader Joe's",
  status: "needs_action" 
})

// Add items to lists
Home Assistant:HassListAddItem({ 
  name: "Mealie Walmart",
  item: "Ground beef 2lbs" 
})

Home Assistant:HassListAddItem({ 
  name: "Mealie Trader Joe's",
  item: "Organic marinara sauce" 
})
```

**De-duplication:**
- Cross-reference recipe ingredients against Mealie foods on-hand
- Only add items not already in inventory
- Combine quantities for duplicate items across recipes

### Phase 6: Summary & Budget Awareness

**Provide comprehensive summary:**

1. Meal plan summary:
   - Date range and total meals planned
   - Leftover rehydration schedule
   - Takeout count and specific nights
2. Shopping summary:
   - Items per store
   - Estimated trip count
3. Budget check:
   - Takeout frequency for this planning window
   - Alert if >3 nights: "That's busy - we're at X takeout nights. Want to swap one for a quick meal?"
4. Confirm Mealie meal plan entries created
5. Confirm shopping lists updated in Home Assistant

## Response Patterns

**Initiating:**
```
User: "Gotta meal plan Claude"
Claude: "I hear ya - [contextual calendar observation]. How much shopping 
        are you ready to do now?"
```

**Leftovers:**
```
Claude: "Any leftovers we should work with? I see you made [meal] with 
        the [kids] [day]."
User: "Yeah, plus [other leftover]"
Claude: "Great - let's reheat [leftover] [day when appropriate kids home]."
```

**Inventory:**
```
User: "Half gallon milk, two packs spaghetti, ground beef, bell peppers..."
Claude: "Got it - updating inventory. With that spaghetti and beef, we 
        could do quick Bolognese on Tuesday's busy night."
```

**Schedule-aware:**
```
Claude: "Looking at Wednesday - both kids have activities until 7:30pm. 
        Suggest either slow cooker (prep morning) or takeout. Thoughts?"
```

**Budget awareness:**
```
Claude: "Heads up - we've suggested takeout 4 nights this week. That's 
        more than usual. Want to swap one for a 20-minute option?"
```

## Key Principles

**Voice-first design:**
- Accept natural language input
- Confirm understanding incrementally
- Keep responses concise
- Ask clarifying questions only when needed
- Summarize complex operations clearly

**Context awareness:**
- Always query calendars before planning
- Understand custody patterns (2-5-5-2 schedule)
- Recognize household composition changes
- Time-of-day awareness in responses
- Activity complexity assessment

**Decision fatigue reduction:**
- Auto-suggest meal complexity based on schedule
- Prioritize recipes using on-hand ingredients
- Proactively address busy nights
- Limit decision points
- Default to proven patterns (85/15 rule)

**Food waste prevention:**
- De-duplicate shopping lists against inventory
- Prioritize recipes using existing ingredients
- Plan leftover rehydration across custody cycles
- Flag expiring items for immediate use

**Budget management:**
- Track takeout frequency
- Alert when exceeding threshold (>3/week)
- Frame takeout as strategic vs reactive
- No judgment, just awareness

## Extensions Needed

**Extended Mealie MCP Server:**

The Mealie MCP server needs these additional tools for full functionality:

### Home Assistant Calendar Integration (~50 lines)

```python
import aiohttp
import os
from datetime import datetime, timedelta

# Configuration from environment
HA_URL = os.getenv("HA_URL")  # https://home-assistant.taildda370.ts.net
HA_TOKEN = os.getenv("HA_TOKEN")  # Long-lived access token

@mcp.tool()
async def get_custody_schedule(
    calendar: str,  # "boys_custody_schedule" or "girls_custody_schedule"
    days_ahead: int = 7
) -> dict:
    """Get custody schedule events from Home Assistant calendar"""
    start = datetime.now().isoformat()
    end = (datetime.now() + timedelta(days=days_ahead)).isoformat()
    
    async with aiohttp.ClientSession() as session:
        url = f"{HA_URL}/api/calendars/calendar.{calendar}"
        params = {"start": start, "end": end}
        headers = {"Authorization": f"Bearer {HA_TOKEN}"}
        
        async with session.get(url, params=params, headers=headers) as resp:
            return await resp.json()

@mcp.tool()
async def get_family_events(
    calendar: str,  # "benci_boys" or "boycivengas"
    days_ahead: int = 7
) -> dict:
    """Get family activity events from Home Assistant calendar"""
    start = datetime.now().isoformat()
    end = (datetime.now() + timedelta(days=days_ahead)).isoformat()
    
    async with aiohttp.ClientSession() as session:
        url = f"{HA_URL}/api/calendars/calendar.{calendar}"
        params = {"start": start, "end": end}
        headers = {"Authorization": f"Bearer {HA_TOKEN}"}
        
        async with session.get(url, params=params, headers=headers) as resp:
            return await resp.json()

@mcp.tool()
async def get_all_calendars() -> dict:
    """List all available calendars in Home Assistant"""
    async with aiohttp.ClientSession() as session:
        url = f"{HA_URL}/api/calendars"
        headers = {"Authorization": f"Bearer {HA_TOKEN}"}
        
        async with session.get(url, headers=headers) as resp:
            return await resp.json()
```

### Mealie Inventory Management Tools

```python
@mcp.tool()
async def update_food_quantity(
    food_id: str,
    quantity: float,
    unit: str = None
) -> dict:
    """Update quantity for a food item in on-hand inventory"""
    # PATCH /api/households/foods/{food_id}
    # Update householdsWithIngredientFood quantity

@mcp.tool()  
async def add_food_to_inventory(
    name: str,
    quantity: float = 1.0,
    unit: str = None
) -> dict:
    """Add new food item to on-hand inventory"""
    # POST /api/foods
    # Then PATCH to add to household inventory
    
@mcp.tool()
async def remove_food_from_inventory(
    food_id: str
) -> dict:
    """Remove food from on-hand inventory"""
    # PATCH /api/households/foods/{food_id}
    # Remove from householdsWithIngredientFood
```

**Deployment Configuration:**

```yaml
# Kubernetes deployment environment variables
env:
  - name: MEALIE_URL
    value: "https://mealie-mcp-server.taildda370.ts.net"
  - name: MEALIE_TOKEN
    valueFrom:
      secretKeyRef:
        name: mealie-mcp-secrets
        key: mealie-token
  - name: HA_URL
    value: "https://home-assistant.taildda370.ts.net"
  - name: HA_TOKEN
    valueFrom:
      secretKeyRef:
        name: mealie-mcp-secrets
        key: ha-token
```

These endpoints enable:
- **Phase 1**: Calendar-aware context discovery
- **Phase 3**: Voice inventory updates (once inventory tools implemented)

Until inventory tools are implemented, track inventory updates in conversation context.

## References

- **MCP Extension Guide**: See references/mcp-extension-guide.md for complete implementation of Home Assistant calendar tools
- **Shopping intelligence**: See references/shopping-intelligence.md for receipt learning and location-based store assignment
- **Full examples**: See references/examples.md for complete multi-phase planning sessions

## Success Metrics

This skill succeeds when it:
1. Reduces cognitive load - planning feels effortless
2. Eliminates decision fatigue - clear suggestions matched to reality
3. Prevents food waste - uses on-hand items, tracks leftovers
4. Reduces reactive takeout - strategic planning prevents "forgot to shop"
5. Manages budget - awareness of takeout frequency
6. Fits real life - adapts to custody schedules, activities, chaos
7. Saves time - voice workflow faster than manual
8. Increases variety - explores new recipes, avoids repetition